from src.domain.book import Book


class BookService:
    def __init__(self, validator, repository_txt, repository_bin):
        self.__validator = validator
        self.__txt_repository = repository_txt
        self.__bin_repository = repository_bin

    def add_book(self, book_id, title, author, undo_stack: list):
        book = Book(book_id, title, author)
        self.__validator.validate(book)
        undo_stack.append(("add", book))
        self.__txt_repository.add(book)
        self.__bin_repository.add(book)

    def remove_book(self, title, undo_stack: list):
        books_to_remove = [book for book in self.__txt_repository if book.title.lower().startswith(title.lower())]
        for book in books_to_remove:
            self.__txt_repository.remove(book.title)
            self.__bin_repository.remove(book.title)
        undo_stack.append(("remove", books_to_remove))


    def search_books(self, search_term):
        searched_books = self.__txt_repository.find(search_term)
        if type(searched_books) != list:
            return [searched_books]
        return searched_books
