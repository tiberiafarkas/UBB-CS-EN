from src.domain.book import Book
from faker.proxy import Faker
from src.repository.MemoryRepository import BookMemoryRepository
from src.repository.TextFileRepository import BookTextRepository
from src.repository.BinaryFileRepository import BookBinaryRepo
from src.ui.ui import UI


def generate_books():
    book_list = []
    book_list.append(Book("1", "The Great Gatsby", "F. Scott Fitzgerald"))
    book_list.append(Book("2", "To Kill a Mockingbird", "Harper Lee"))
    book_list.append(Book("3", "1984", "George Orwell"))
    book_list.append(Book("4", "Six of Crows", "Leigh Bardugo"))
    book_list.append(Book("5", "A little life", "Hanya Yanagihara"))
    book_list.append(Book("6", "Ninth House", "Leigh Bardugo"))
    book_list.append(Book("7", "A good girl's guide to murder", "Holly Jackson"))
    book_list.append(Book("8", "Project Hail Mary", "Andy Weir"))
    book_list.append(Book("9", "Dune", "Frank Herbert"))
    book_list.append(Book("10", "The Order", "Daniel Silva"))
    return book_list



if __name__ == "__main__":
    # books = generate_books()
    # book_text_repo = BookTextRepository()
    # book_bin_repo = BookBinaryRepo()
    # for book in books:
    #     book_bin_repo.add(book)
    #     book_text_repo.add(book)

    ui = UI()
    ui.run()
