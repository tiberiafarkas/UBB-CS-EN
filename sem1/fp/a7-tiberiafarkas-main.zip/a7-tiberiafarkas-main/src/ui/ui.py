# src/ui/ui.py
from src.domain.book import Book, BookValidator
from src.repository.TextFileRepository import BookTextRepository
from src.repository.BinaryFileRepository import BookBinaryRepo
from src.services.book_services import BookService


class UI:
    def __init__(self):
        self.book_text_repo = BookTextRepository()
        self.book_bin_repo = BookBinaryRepo()
        self.validator = BookValidator()
        self.book_service = BookService(self.validator, self.book_text_repo, self.book_bin_repo)
        self.commands = {
            "1": self.add_book,
            "2": self.remove_books,
            "3": self.list_books,
            "4": self.undo_last_operation
        }
        self.undo_stack = []

    def print_menu(self):
        print("0. Exit")
        print("1. Add a new book")
        print("2. Remove books starting with a given title")
        print("3. List all books")
        print("4. Undo the last operation")

    def add_book(self):
        isbn = input("Enter ISBN: ")
        title = input("Enter title: ")
        author = input("Enter author: ")

        self.book_service.add_book(isbn, title, author, self.undo_stack)
        print("Book added successfully.")

    def remove_books(self):
        title = input("Enter a word to remove books starting with it: ")
        self.book_service.remove_book(title, self.undo_stack)
        print("Books removed successfully.")

    def list_books(self):
        print("Books in text repository:")
        for book in self.book_text_repo:
            print(book)
        print("Books in binary repository:")
        for book in self.book_bin_repo:
            print(book)

    def undo_last_operation(self):
        if not self.undo_stack:
            print("No operations to undo.")
            return

        operation, books = self.undo_stack.pop()
        if operation == "add":
            self.book_text_repo.remove(books.title)
            self.book_bin_repo.remove(books.title)
        elif operation == "remove":
            for book in books:
                self.book_text_repo.add(book)
                self.book_bin_repo.add(book)
        print("Last operation undone.")

    def run(self):
        while True:
            self.print_menu()
            command = input(">>> ")
            if command == "0":
                break
            elif command in self.commands:
                self.commands[command]()
            else:
                raise ValueError("Invalid command.")

if __name__ == "__main__":
    ui = UI()
    #ui.run()

