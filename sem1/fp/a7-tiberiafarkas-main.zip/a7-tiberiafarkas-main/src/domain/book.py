class Book:
    """Each book has an isbn (string, unique), an author and a title (strings)"""

    def __init__(self, isbn: str, title: str, author: str):
        self.__id = isbn
        self.__title = title
        self.__author = author

    def __str__(self):
        return f"{self.__id}, {self.title}, {self.author}"

    #we want to read the id, but we don't want to change it

    @property
    def id(self):
        return self.__id

    @property
    def title(self):
        return self.__title

    @property
    def author(self):
        return self.__author


def test_book():
    new_book = Book("123", "The book", "The author")
    assert new_book.id == "123"
    assert new_book.title == "The book"
    assert new_book.author == "The author"

test_book()

class BookValidator:
    def __init__(self):
        self.__errors = []

    def validate(self, book):
        if not isinstance(book, Book):
            raise TypeError("Can only validate Book objects!")

        try:
            if int(book.id) < 0:
                self.__errors.append("ID must be a positive integer")
        except TypeError:
            self.__errors.append("ID must be an integer")

        if book.title == "":
            self.__errors.append("Title cannot be empty")

        if book.author == "":
            self.__errors.append("Author cannot be empty")

        if len(self.__errors) > 0:
            raise ValueError(self.__errors)

        return True