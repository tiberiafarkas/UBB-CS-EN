from src.domain.book import Book
from src.repository.MemoryRepository import BookMemoryRepository


class BookTextRepository(BookMemoryRepository):
    def __init__(self, file_name: str = "../ui/books.txt"):
        super().__init__()
        self._file_name = file_name
        self._load_file()

    def _load_file(self):
        try:
            with open(self._file_name, "r") as f:
                lines = f.readlines()
                for line in lines:
                    # line = line.strip()
                    # if line == "":
                    #     continue
                    tokens = line.split(",")
                    super().add(Book(tokens[0], tokens[1].strip(), tokens[2].strip()))
                f.close()
        except FileNotFoundError:
            print("File not found")

    def _save_file(self):
        with open(self._file_name, "w") as f:
            for book in self._data.values():
                f.write(book.id + "," + book.title + "," + book.author + "\n")
            f.close()

    def add(self, book):
        super().add(book)
        self._save_file()

    def remove(self, book_title) -> Book:
        book_object =  super().remove(book_title)
        self._save_file()
        return book_object

if __name__ == "__main__":
    try:
        repo = BookTextRepository()
        for book in repo:
            print(book)
    except FileNotFoundError as e:
        print("FileNotFoundError")
    except Exception as e:
        print(e)