class RepositoryError(Exception):
    def __init__(self, message: str = ""):
        self.__message = message

    @property
    def message(self):
        return self.__message

class DuplicateIDError(RepositoryError):
    pass

class IDNotFoundError(RepositoryError):
    pass

class RepositoryIterator():
    def __init__(self, data):
        self.__data = data
        self.__pos = -1

    def __next__(self):
        self.__pos += 1
        if len(self.__data) == self.__pos:
            raise StopIteration()

        return self.__data[self.__pos]

class BookMemoryRepository:
    def __init__(self):
        self._data = {}

    def add(self, element):
        if element.id in self._data:
            raise DuplicateIDError("Duplicate object ID")
        self._data[element.id] = element

    def remove(self, book_title: str):
        found_books = [book_id for book_id, book in self._data.items() if book.title == book_title]
        if not found_books:
            raise IDNotFoundError("Book title not found")
        for book_id in found_books:
            del self._data[book_id]
        return found_books

    def find(self, elem_id: int):
        if elem_id not in self._data:  # is the elem_id already a key in the dict?
            return None
        return self._data[elem_id]

    def __iter__(self):
        # create an iterator for the repository
        return iter(self._data.values())

    def __len__(self):
        return len(self._data)

    def __getitem__(self, item):
        if item not in self._data:
            return None
        return self._data[item]

