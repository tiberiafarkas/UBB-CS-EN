import pickle

from src.domain.book import Book
from src.repository.MemoryRepository import BookMemoryRepository

class RepositoryError(Exception):
    def __init__(self, message: str = ""):
        self.__message = message

    @property
    def message(self):
        return self.__message

class DuplicateIDError(RepositoryError):
    pass

class BookBinaryRepo(BookMemoryRepository):
    def __init__(self, file_name: str = "../ui/books.bin"):
        super().__init__()  #goes to the upper class -> in this case bookmemoryrepository
        self._file_name = file_name
        self._load_file()

    def _load_file(self):
        try:
            with open(self._file_name, "rb") as f:
                self._data = pickle.load(f)
                f.close()
        except (FileNotFoundError, EOFError):
            self._data = {}

    def _save_file(self):
        with open(self._file_name, "wb") as f:
            pickle.dump(self._data, f)
            f.close()

    def add(self, element):
        if element.id in self._data:
            raise DuplicateIDError("Duplicate object ID")
        self._data[element.id] = element
        self._save_file()

    def remove(self, book_title: str):
        super().remove(book_title)
        self._save_file()

if __name__ == "__main__":
    try:
        repo = BookBinaryRepo()
        for book in repo:
            print(book)
    except FileNotFoundError as e:
        print("FileNotFoundError")
    except Exception as e:
        print(e)