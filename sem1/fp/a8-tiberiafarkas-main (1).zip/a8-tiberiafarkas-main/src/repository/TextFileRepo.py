from datetime import datetime
from multiprocessing.dummy import Value

from src.domain.book import Book
from src.domain.client import Client
from src.domain.rental import Rental
from src.repository.MemoryRepository import MemoryRepository, IDNotFoundError


class BookTextFileRepo(MemoryRepository):
    def __init__(self, file_name: str):
        super().__init__()
        self.__file_name = file_name
        self._file_loaded = False
        self.__load()

    def add(self, element):
        super().add(element)
        self.__save()

    def remove(self, book_id: int):
        book_to_remove = None
        for book in self._data.values():
            if book.id == int(book_id):
                book_to_remove = book
                self.__save()
                break
        if book_to_remove:
            del self._data[book_to_remove.id]
            self.__save()
        else:
            raise KeyError(f"Book with id '{book_id}' not found")

    def find(self, search_term):
        results = []
        try:
            search_term = int(search_term)
            # Search by ID
            for book in self:
                if book.id == search_term:
                    results.append(book)
                    return book
        except ValueError:
            # Search by title or author
            search_term = search_term.lower()
            for book in self:
                if search_term in book.title.lower() or search_term in book.author.lower():
                    results.append(book)
        return results

    def update(self, book_id, new_title, new_author):
        if book_id not in self._data:
            raise IDNotFoundError("ID not found")
        self._data[book_id].title = new_title
        self._data[book_id].author = new_author
        self.__save()

    def __iter__(self):
        return super().__iter__()

    def __len__(self):
        return super().__len__()

    def __getitem__(self, item):
        return super().__getitem__()

    def __load(self):
        """
        Load the data from the file
        :return:
        """

        if self._file_loaded is True:
            """
            If the file has already been loaded, you don't need to load it again
            """
            return
        self._file_loaded = True
        try:
            """ 
            Here it tries to open the file with the given name 
            """
            fin = open(self.__file_name, "rt")  #rt - read text
        except FileNotFoundError:
            return

        """
        Read the lines from the file
        """
        line = fin.readline()

        while len(line) > 0:
            """
            Split the data from a line by a comma
            tokens[0] = id
            tokens[1] = title
            tokens[2] = author
            This is how it would look like
            """
            tokens = line.split(",")
            super().add(Book(tokens[0], tokens[1], tokens[2].strip()))
            line = fin.readline()
        fin.close()

    def __save(self):
        """
        Save the data to the file
        :return:
        """
        fout = open(self.__file_name, "wt") #wt - write text
        for book in self:
            fout.write(f"{book.id},{book.title},{book.author}\n")
        fout.close()

class ClientTextFileRepo(MemoryRepository):
    def __init__(self, file_name: str):
        super().__init__()
        self._file_loaded = False
        self.__file_name = file_name
        self.__load()

    def add(self, element):
        super().add(element)
        self.__save()

    def remove(self, client_id):
        super().remove(client_id)
        self.__save()

    def find(self, search_term):
        results = []
        try:
            search_term = int(search_term)
            # Search by ID
            for client in self:
                if client.id == search_term:
                    return client
        except ValueError:
            # Search by name
            search_term = search_term.strip().lower()
            for client in self:
                if search_term in client.name.strip().lower():
                    results.append(client)

        return results

    def search(self, query):
        results = [client for client in self._data.values() if query.lower() in client.name.lower()]
        return results

    def update(self, client_id, new_name):
        client_id = int(client_id)
        if client_id not in self._data:
            raise IDNotFoundError("ID not found")
        self._data[client_id].name = new_name
        self.__save()

    def __iter__(self):
        return super().__iter__()

    def __len__(self):
        return super().__len__()

    def __getitem__(self, item):
        return super().__getitem__()

    def __load(self):
        if self._file_loaded:
            return
        self._file_loaded = True
        try:
            with open(self.__file_name, 'rt') as fin:
                for line in fin:
                    if line.strip():  # Skip empty lines
                        tokens = line.split(',')
                        super().add(Client(int(tokens[0]), tokens[1].strip()))
        except FileNotFoundError:
            return

    def __save(self):
        fout = open(self.__file_name, "wt", newline ='')
        for client in self:
            fout.write(f"{client.id},{client.name}\n")
        fout.close()

class RentalTextFileRepo(MemoryRepository):
    def __init__(self, book_repo: MemoryRepository, client_repo: MemoryRepository, file_name: str):
        super().__init__()
        self.__book_repo = book_repo
        self.__client_repo = client_repo
        self.__file_name = file_name
        self._file_loaded = False
        self.__load()

    def add(self, element):
        super().add(element)
        self.__save()

    def remove(self, elem_id: int):
        super().remove(elem_id)
        self.__save()

    def find(self, elem_id):
        try:
            elem_id = int(elem_id)
            for rental in self:
                if int(rental.id) == elem_id:
                    return rental
        except ValueError:
            raise ValueError(f"Rental with id {elem_id} doesn't exist")

    # def get_last_rental_id(self, book_id: int):
    #     last_rental_id = None
    #     for rental in self:
    #         if rental.book.id == book_id:
    #             if last_rental_id is None or rental.id > last_rental_id:
    #                 last_rental_id = rental.id
    #     return last_rental_id

    def update(self, rental, returned_date):
        if rental.id not in self._data:
            raise IDNotFoundError("ID not found")
        self._data[rental.id].returned_date = returned_date
        self.__save()

    def __iter__(self):
        return super().__iter__()

    def __len__(self):
        return super().__len__()

    def __getitem__(self, item):
        return super().__getitem__(item)

    def get_all(self):
        return self._data.values()

    def __load(self):
        if self._file_loaded is True:
            return
        self._file_loaded = True
        try:
            fin = open(self.__file_name, "rt")
        except FileNotFoundError:
            return

        for line in fin:
            if line.strip():
                tokens = line.split(',')
                if len(tokens) != 5:
                    raise ValueError(f"Incorrect number of tokens in line: {line}")

                rental_id = tokens[0]
                book_id = tokens[1]
                client_id = tokens[2]
                rented_date = datetime.strptime(tokens[3], "%Y-%m-%d").date()
                due_date = datetime.strptime(tokens[4].strip(), "%Y-%m-%d").date()

                book = self.__book_repo.find(int(book_id))
                client = self.__client_repo.find(int(client_id))

                super().add(Rental(rental_id, book, client, rented_date, due_date))

        fin.close()

    def __save(self):
        fout = open(self.__file_name, "wt")
        for rental in self:
            #print(type(rental.client))
            fout.write(str(rental.id) + "," + str(rental.book.id) + "," + str(rental.client.id) + "," + str(rental.rented_date) + "," + str(rental.returned_date)  + "\n")
        fout.close()