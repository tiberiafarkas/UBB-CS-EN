class Client(object):
    def __init__(self, client_id: str, name: str):
        self.__id = int(client_id)
        self.__name = name

    @property
    def id(self):
        return self.__id

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    def __str__(self):
        return f"{self.id} - {self.name}"

    def __repr__(self):
        return str(self)

def test_client():
    c = Client(1, 'name')
    assert c.id == 1
    assert c.name == 'name'
    assert str(c) == '1 - name'

test_client()

class ClientValidator:
    def __init__(self):
        self.__errors = []

    def validate(self, client):
        if not isinstance(client, Client):
            raise TypeError("Can only validate Client objects!")

        try:
            int(client.id)
        except ValueError:
            self.__errors.append("ID must be an integer")

        try:
            if client.id < 0:
                self.__errors.append("ID must be a positive integer")
        except TypeError:
            self.__errors.append("ID must be an integer")

        if client.name == "":
            self.__errors.append("Name cannot be empty")

        if len(self.__errors) > 0:
            raise ValueError(self.__errors)

        return True