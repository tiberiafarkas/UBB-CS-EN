from datetime import date, datetime

from src.domain.book import Book
from src.domain.client import Client


class Rental(object):
    def __init__(self, rental_id, book: Book, client: Client, rented_date: date, returned_date: date):
        self.__id = int(rental_id)
        self.__client = client
        self.__book = book
        self.__returned_date = returned_date
        self.__rented_date = rented_date

    @property
    def id(self):
        return self.__id

    @property
    def client(self):
        return self.__client

    @property
    def book(self):
        return self.__book

    @property
    def returned_date(self):
        return self.__returned_date

    @property
    def rented_date(self):
        return self.__rented_date

    @returned_date.setter
    def returned_date(self, returned_date):
        self.__returned_date = returned_date

    def __str__(self):
        from_date = self.__rented_date.strftime("%Y-%m-%d")
        to_date = self.__returned_date.strftime("%Y-%m-%d")
        return f'{self.id}, [client {self.client}] - [book {self.book}] - from {from_date} to {to_date}'

    def __repr__(self):
        return str(self)

def test_rental():
    client = Client(1, 'client')
    book = Book(1, 'book', 'author')
    r = Rental(1, book, client, date(2021, 12, 1), date(2021, 12, 5))
    assert r.id == 1
    assert r.client == client
    assert r.book == book
    assert r.rented_date == date(2021, 12, 1)
    assert r.returned_date == date(2021, 12, 5)
    assert str(r) == f'1, [client {client}] - [book {book}] - from 2021-12-01 to 2021-12-05'

test_rental()

class RentalValidator:
    def __init__(self):
        self.__errors = []

    def validate(self, rental):
        if not isinstance(rental, Rental):
            raise TypeError("Can only validate Rental objects!")

        try:
            int(rental.id)
        except ValueError:
            self.__errors.append("ID must be an integer")

        try:
            if rental.id < 0:
                self.__errors.append("ID must be a positive integer")
        except TypeError:
            self.__errors.append("ID must be an integer")

        if rental.client is None:
            self.__errors.append("Client cannot be None")

        if rental.book is None:
            self.__errors.append("Book cannot be None")

        if rental.rented_date is None:
            self.__errors.append("Rented date cannot be None")

        now = date(2000, 1, 1)  # Convert to date

        if rental.rented_date < now:
            self.__errors.append("Rented date cannot be in the past")

        if rental.returned_date is None:
            self.__errors.append("Returned date cannot be None")

        if rental.rented_date == rental.returned_date:
            self.__errors.append("Rented date cannot be the same as returned date")

        if rental.rented_date > rental.returned_date:
            self.__errors.append("Rented date cannot be after returned date")

        if len(self.__errors) > 0:
            raise ValueError(self.__errors)

        return True