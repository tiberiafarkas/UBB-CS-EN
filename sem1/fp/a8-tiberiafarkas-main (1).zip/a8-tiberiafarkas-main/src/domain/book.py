class Book:
    def __init__(self, id: str, title: str, author: str):
        self.__id = int(id)
        self.__title = title
        self.__author = author

    def __str__(self):
        return f'{self.id} - {self.title} by {self.author}'

    @property
    def id(self):
        return self.__id

    @property
    def title(self):
        return self.__title

    @property
    def author(self):
        return self.__author

    @title.setter
    def title(self, value):
        self.__title = value

    @author.setter
    def author(self, value):
        self.__author = value

def test_book():
    b = Book(1, 'title', 'author')
    assert b.id == 1
    assert b.title == 'title'
    assert b.author == 'author'
    assert str(b) == '1 - title by author'

test_book()

class BookValidator:
    def __init__(self):
        self.__errors = []

    def validate(self, book):
        if not isinstance(book, Book):
            raise TypeError("Can only validate Book objects!")

        try:
            int(book.id)
        except ValueError:
            self.__errors.append("ID must be an integer")

        try:
            if book.id < 0:
                self.__errors.append("ID must be a positive integer")
        except TypeError:
            self.__errors.append("ID must be an integer")

        if book.title == "":
            self.__errors.append("Title cannot be empty")

        if book.author == "":
            self.__errors.append("Author cannot be empty")

        if len(self.__errors) > 0:
            raise ValueError(self.__errors)

        return True