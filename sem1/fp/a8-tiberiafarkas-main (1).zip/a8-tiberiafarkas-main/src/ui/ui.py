from datetime import datetime

from src.domain.book import Book, BookValidator
from src.domain.client import Client, ClientValidator
from src.domain.rental import Rental, RentalValidator
from src.repository.TextFileRepo import BookTextFileRepo, ClientTextFileRepo, RentalTextFileRepo
from src.services.book_services import BookService
from src.services.client_service import ClientService
from src.services.rental_services import RentalService


class UI:
    def __init__(self, book_repo, client_repo, rental_repo):
        self.__book_repo = book_repo
        self.__client_repo = client_repo
        self.__rental_repo = rental_repo
        self.__book_validator = BookValidator()
        self.__client_validator = ClientValidator()
        self.__rental_validator = RentalValidator()
        self.__book_service = BookService(self.__book_validator, self.__book_repo)
        self.__client_service = ClientService(self.__client_validator, self.__client_repo)
        self.__rental_service = RentalService(self.__rental_validator, self.__rental_repo, self.__book_repo, self.__client_repo)
        self.index = 0
        self.command = {
            "1": self.add_book,
            "2": self.add_client,
            "3": self.remove_book,
            "4": self.remove_client,
            "5": self.update_book,
            "6": self.update_client,
            "7": self.list_books,
            "8": self.list_clients,
            "9": self.rent_book,
            "10": self.return_book,
            "11": self.search_books,
            "12": self.search_clients
        }

    def print_menu(self):
        print("1. Add book")
        print("2. Add client")
        print("3. Remove book")
        print("4. Remove client")
        print("5. Update book")
        print("6. Update client")
        print("7. List books")
        print("8. List clients")
        print("9. Rent book")
        print("10. Return book")
        print("11. Search books")
        print("12. Search clients")
        print("0. Exit")

    def add_book(self):
        book_id = input("Enter book id: ")
        title = input("Enter title: ")
        author = input("Enter author: ")
        self.__book_service.add_book(book_id, title, author)

    def add_client(self):
        client_id = input("Enter client id: ")
        name = input("Enter name: ")
        client = Client(client_id, name)
        self.__client_repo.add(client)

    def remove_book(self):
        book_id = input("Enter book id to remove: ")
        #here i should remove also all the rentals of that book
        self.__rental_service.remove_rentals_by_book_id(book_id)
        self.__book_service.remove_book(book_id)

    def remove_client(self):
        client_id = input("Enter client id to remove: ")
        #here i should also remove all the rentals of that client
        self.__rental_service.remove_rentals_by_client_id(client_id)
        self.__client_service.remove_client(client_id)

    def update_book(self):
        book_id = input("Enter book id to update: ")
        new_title = input("Enter new title: ")
        new_author = input("Enter new author: ")
        self.__book_service.update_book(book_id, new_title, new_author)

    def update_client(self):
        client_id = input("Enter client id to update: ")
        new_name = input("Enter new name: ")
        self.__client_service.update_client(client_id, new_name)

    def list_books(self):
        print("Books in text repository:")
        for book in self.__book_repo:
            print(book)

    def list_clients(self):
        print("Clients in text repository:")
        for client in self.__client_repo:
            print(client)

    def rent_book(self):
        client_id = input("Enter client id: ")
        book_id = input("Enter book id: ")
        date_str = input("Enter date (YYYY-MM-DD): ")
        rental_book = self.__rental_service.create_rental(book_id, client_id, date_str)
        print(rental_book)

    def return_book(self):
        rental_id = input("Enter rental id to return: ")
        returned_date = input("Enter date (YYYY-MM-DD): ")
        self.__rental_service.return_rental(rental_id, returned_date)

    def search_books(self):
        search_term = input("Enter book ID, title, or author to search: ")
        results = self.__book_service.search_books(search_term)
        for book in results:
            print(book)

    def search_clients(self):
        search_term = input("Enter client ID or name to search: ")
        results = self.__client_service.search_clients(search_term)
        for client in results:
            print(client)
        else:
            print("No clients found")

    def run(self):
        while True:
            self.print_menu()
            command = input(">>> ")
            if command == "0":
                break
            if command in self.command:
                self.command[command]()
            else:
                raise ValueError("Invalid command")