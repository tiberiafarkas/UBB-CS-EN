import configparser
from datetime import date, timedelta
from random import randint, choice

from faker.proxy import Faker

from src.domain.book import Book
from src.domain.client import Client
from src.domain.rental import Rental
from src.repository.BinaryFileRepo import BookBinaryRepo, ClientBinaryRepo, RentalBinaryRepo
from src.repository.MemoryRepository import MemoryRepository
from src.repository.TextFileRepo import BookTextFileRepo, ClientTextFileRepo, RentalTextFileRepo
from src.services.settings import Settings
from src.ui.ui import UI


def generate_books():
    book_list = []
    book_list.append(Book(1, "The Great Gatsby", "F. Scott Fitzgerald"))
    book_list.append(Book(2, "To Kill a Mockingbird", "Harper Lee"))
    book_list.append(Book(3, "1984", "George Orwell"))
    book_list.append(Book(4, "Six of Crows", "Leigh Bardugo"))
    book_list.append(Book(5, "A little life", "Hanya Yanagihara"))
    book_list.append(Book(6, "Ninth House", "Leigh Bardugo"))
    book_list.append(Book(7, "A good girl's guide to murder", "Holly Jackson"))
    book_list.append(Book(8, "Project Hail Mary", "Andy Weir"))
    book_list.append(Book(9, "Dune", "Frank Herbert"))
    book_list.append(Book(10, "The Order", "Daniel Silva"))
    book_list.append(Book(11, "The People in the Trees", "Hanya Yanagihara"))
    book_list.append(Book(12, "Everyone in My Family Has Killed Someone", "Benjamin Stevenson"))
    book_list.append(Book(13, "Shatter Me", "Tahereh Mafi"))
    book_list.append(Book(14, "The Color Purple", "Alice Walker"))
    book_list.append(Book(15, "A Gentleman in Moscow", "Amor Towles"))
    book_list.append(Book(16, "The It Girl", "Ruth Ware"))
    book_list.append(Book(17, "Inferno", "Dante Alighieri"))
    book_list.append(Book(18, "iNGERII sUNT cIRCUITE", "Ana-The + AnnDee"))  #credits to one of my best friends - lets hope this book will be published in 2025
    book_list.append(Book(19, "Sigmund Freud: de la tragedie la psihanaliza", "Pierre Babin"))
    book_list.append(Book(20, "To Sleep in a Sea of Stars", "Christopher Paolini"))
    return book_list

def generate_clients():
    client_list = []
    fake = Faker()

    for client_id in range(100, 121):
        client_list.append(Client(client_id, fake.name()))
    return client_list


def generate_rentals(book_list: [Book], client_list: [Client]):
    rental_list = []
    for rental_id in range(1, 21):
        rented_date = date(2024, randint(1, 12), randint(1, 28))
        returned_date = rented_date + timedelta(days=randint(1, 30))
        rental_list.append(Rental(rental_id, choice(book_list), choice(client_list), rented_date, returned_date))
    return rental_list


if __name__ == "__main__":
    settings = Settings.get_instance()
    repository_type = settings.repository_type
    book_file = settings.books_file
    client_file = settings.client_file
    rental_file = settings.rentals_file

    if repository_type == 'inmemory':
         book_repo = MemoryRepository()
         client_repo = MemoryRepository()
         rental_repo = MemoryRepository()
    elif repository_type == 'textfile':
        book_repo = BookTextFileRepo(book_file)
        client_repo = ClientTextFileRepo(client_file)
        rental_repo = RentalTextFileRepo(book_repo, client_repo, rental_file)
    elif repository_type == 'binary':
        book_repo = BookBinaryRepo(book_file)
        client_repo = ClientBinaryRepo(client_file)
        rental_repo = RentalBinaryRepo(book_repo, client_repo, rental_file)
    else:
        raise ValueError(f"Unknown repository type: {repository_type}")

    # book_rep = BookTextFileRepo("books.txt")
    # # # for book in generate_books():
    # # #     book_rep.add(book)
    # # # #
    # client_rep = ClientTextFileRepo("clients.txt")
    # # # for client in generate_clients():
    # # #     client_rep.add(client)
    # rental_rep = RentalTextFileRepo(book_rep, client_rep, "rentals.txt")
    # for rental in generate_rentals(generate_books(), generate_clients()):
    #     rental_rep.add(rental)
    # #
    # books_repo = BookBinaryRepo("books.bin")
    # # for book in generate_books():
    # #     books_repo.add(book)
    # #
    # clients_repo = ClientBinaryRepo("clients.bin")
    # # for client in generate_clients():
    # #     clients_repo.add(client)
    # # #
    # rentals_repo = RentalBinaryRepo(books_repo, clients_repo, "rentals.bin")
    # for rental in generate_rentals(generate_books(), generate_clients()):
    #     rentals_repo.add(rental)

    ui = UI(book_repo, client_repo, rental_repo)
    ui.run()