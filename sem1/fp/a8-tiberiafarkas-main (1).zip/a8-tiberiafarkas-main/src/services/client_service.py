from src.domain.client import Client


class ClientService:
    def __init__(self, validator, repository):
        self.__validator = validator
        self.__repository = repository

    def add_client(self, client_id, name):
        client = Client(client_id, name)
        self.__validator.validate(client)
        self.__repository.add(client)

    def remove_client(self, client_id):
        client = self.__repository.find(client_id)
        self.__validator.validate(client)
        self.__repository.remove(int(client_id))

    def update_client(self, client_id, new_name):
        client = Client(client_id, new_name)
        self.__validator.validate(client)
        self.__repository.update(int(client_id), new_name)

    def search_clients(self, search_term):
        searched_clients = self.__repository.find(search_term)
        if type(searched_clients) != list:
            return [searched_clients]
        return searched_clients

