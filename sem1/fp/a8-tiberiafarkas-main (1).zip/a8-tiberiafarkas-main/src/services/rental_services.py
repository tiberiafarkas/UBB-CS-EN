from datetime import datetime, timedelta

from src.domain.book import Book
from src.domain.rental import Rental

class BookRentalException(Exception):
    def __init__(self, message):
        self.__message = message

    def __str__(self):
        return str(self.__message)


class RentalService:
    def __init__(self, validator, repository, book_repo, client_repo):
        self.__validator = validator
        self.__repository = repository
        self.__book_repo = book_repo
        self.__client_repo = client_repo

    def create_rental(self, book_id, client_id, rented_date):
        rental_id = len(self.__repository.get_all()) + 1
        book = self.__book_repo.find(book_id)
        client = self.__client_repo.find(client_id)
        rented_date = datetime.strptime(rented_date, "%Y-%m-%d").date()
        returned_date = rented_date + timedelta(days = 30)
        rental = Rental(rental_id, book, client, rented_date, returned_date)
        self.__validator.validate(rental)

        if self.is_book_available(rental.book, rented_date, returned_date) is False:
            raise BookRentalException("Book is not available for rental")

        self.__repository.add(rental)
        return rental

    def is_book_available(self, book, rented_date, returned_date):
        rentals = self.filter_rentals_books(book)
        for rental in rentals:
            if rented_date < rental.returned_date and returned_date > rental.rented_date:
                return False

        return True

    def filter_rentals_books(self, book):
        results =  []
        for rental in self.__repository.get_all():
            if book is not None and rental.book != book:
                continue

            results.append(rental)
        return results

    def filter_rentals_clients(self, client):
        results =  []
        for rental in self.__repository.get_all():
            if client is not None and rental.client != client:
                continue

            results.append(rental)
        return results

    def return_rental(self, rental_id, returned_date):
        rental = self.__repository.find(rental_id)
        returned_date = datetime.strptime(returned_date, "%Y-%m-%d").date()
        new_rental = Rental(rental.id, rental.book, rental.client, rental.rented_date, returned_date)
        self.__validator.validate(new_rental)
        self.__repository.update(rental, returned_date)

    def remove_rentals_by_book_id(self, book_id):
        book = self.__book_repo.find(book_id)
        for rental in self.filter_rentals_books(book):
            self.__repository.remove(rental.id)

    def remove_rentals_by_client_id(self, client_id):
        client = self.__client_repo.find(client_id)
        for rental in self.filter_rentals_clients(client):
            self.__repository.remove(rental.id)

