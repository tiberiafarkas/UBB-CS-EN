from src.domain.book import Book


class BookService:
    def __init__(self, validator, repository):
        self.__validator = validator
        self.__repository = repository

    def add_book(self, book_id, title, author):
        book = Book(book_id, title, author)
        self.__validator.validate(book)
        self.__repository.add(book)

    def remove_book(self, book_id):
        book = self.__repository.find(book_id)
        self.__validator.validate(book)
        self.__repository.remove(book_id)

    def update_book(self, book_id, new_title, new_author):
        book = Book(book_id, new_title, new_author)
        self.__validator.validate(book)
        self.__repository.update(int(book_id), new_title, new_author)

    def search_books(self, search_term):
        searched_books = self.__repository.find(search_term)
        if type(searched_books) != list:
            return [searched_books]
        return searched_books
