from enum import Enum

class RepositoryType(Enum):
    pass

class Settings:

    __instance = None   #not linked to any object of type setting, but it is linked to the settings class itself

    @staticmethod
    def get_instance():
        if Settings.__instance is not None:
            return Settings.__instance

        #we create the singular settings object here, only if it has not yet been created
        fin = open("settings.properties", "rt")
        file_lines = fin.readlines()
        fin.close()

        settings_dict = {}

        for line in file_lines:
            #print(line)
            if line.strip().startswith("#"):
                continue    #this is a comment, so move to the next iteration of the innermost loop
            #print(line)
            tokens = line.strip().split("=")
            #print(tokens)
            settings_dict[tokens[0].strip()] = tokens[1].strip()

        repo_type = settings_dict["repository"]
        books_file = settings_dict["books"]
        client_file = settings_dict["clients"]
        rentals_file = settings_dict["rentals"]

        Settings.__instance = Settings(repo_type, books_file, client_file, rentals_file)
        return Settings.__instance

    def __init__(self, repo_type: str, books_file: str, client_file: str, rentals_file: str):
        self.__repo_type = repo_type
        self.__books_file = books_file
        self.__client_file = client_file
        self.__rentals_file = rentals_file

    @property
    def repository_type(self):
        return self.__repo_type

    @property
    def books_file(self):
        return self.__books_file

    @property
    def client_file(self):
        return self.__client_file

    @property
    def rentals_file(self):
        return self.__rentals_file

# settings_one = Settings.get_instance()
# print(settings_one.repository_type)