from src.domain.client import Client
from src.services.undo_service import CascadedOperation, FunctionCall


class ClientService:
    def __init__(self, validator, repository, undo_redo_service):
        self.__validator = validator
        self.__repository = repository
        self.undo_redo_service = undo_redo_service

    def add_client(self, client_id, name):
        client = Client(client_id, name)
        self.__validator.validate(client)
        self.__repository.add(client)

        undo_redo_operation = CascadedOperation()
        undo_redo_operation.add_undo_function(FunctionCall(self.__repository.remove, client_id))
        undo_redo_operation.add_redo_function(FunctionCall(self.__repository.add, client))
        self.undo_redo_service.record(undo_redo_operation)

    def remove_client(self, client_id, rental_service):
        client = self.__repository.find(client_id)
        self.__validator.validate(client)
        self.__repository.remove(int(client_id))

        undo_redo_operation = CascadedOperation()
        undo_redo_operation.add_undo_function(FunctionCall(self.__repository.add, client))
        undo_redo_operation.add_redo_function(FunctionCall(self.__repository.remove, client_id))

        # if we just removed the book, we need to delete all rentals with that book
        rentals = rental_service.filter_rentals_clients(client)
        for rent in rentals:
            rental_service.remove_rental(rent.client.id)

            undo_redo_operation.add_undo_function(FunctionCall(rental_service.create_rental, rent.book.id, rent.client.id, rent.rented_date, rent.rented_date))
            undo_redo_operation.add_redo_function(FunctionCall(rental_service.remove_rental, rent.client.id))

        self.undo_redo_service.record(undo_redo_operation)

    def update_client(self, client_id, new_name):
        old_client = self.__repository.find(client_id)

        client = Client(client_id, new_name)
        self.__validator.validate(client)

        undo_redo_operation = CascadedOperation()
        undo_redo_operation.add_undo_function(FunctionCall(self.__repository.update, int(client_id), old_client.name))
        undo_redo_operation.add_redo_function(FunctionCall(self.__repository.update, int(client_id), new_name))

        self.undo_redo_service.record(undo_redo_operation)

        self.__repository.update(int(client_id), new_name)

    def search_clients(self, search_term):
        searched_clients = self.__repository.find(search_term)
        if type(searched_clients) != list:
            return [searched_clients]
        return searched_clients

