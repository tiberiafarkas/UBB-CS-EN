from src.domain.book import Book
from src.services.undo_service import CascadedOperation, FunctionCall


class BookService:
    def __init__(self, validator, repository, undo_redo_service):
        self.__validator = validator
        self.__repository = repository
        self.undo_redo_service = undo_redo_service
        #self.__rental_service = rental_service

    def add_book(self, book_id, title, author):
        book = Book(book_id, title, author)
        self.__validator.validate(book)
        self.__repository.add(book)

        undo_redo_operation = CascadedOperation()
        undo_redo_operation.add_undo_function(FunctionCall(self.__repository.remove, book_id))
        undo_redo_operation.add_redo_function(FunctionCall(self.__repository.add, book))
        self.undo_redo_service.record(undo_redo_operation)
        #if we just added the book, we dont need to delete or restore any rentals

    def remove_book(self, book_id, rental_service):
        book = self.__repository.find(book_id)
        self.__validator.validate(book)
        self.__repository.remove(book_id)

        undo_redo_operation = CascadedOperation()
        undo_redo_operation.add_undo_function(FunctionCall(self.__repository.add, book))
        undo_redo_operation.add_redo_function(FunctionCall(self.__repository.remove, book_id))

        #if we just removed the book, we need to delete all rentals with that book
        rentals = rental_service.filter_rentals_books(book)
        for rent in rentals:
            rental_service.remove_rental(rent.book.id)

            undo_redo_operation.add_undo_function(FunctionCall(rental_service.create_rental, rent.book.id, rent.client.id, rent.rented_date, rent.rented_date))
            undo_redo_operation.add_redo_function(FunctionCall(rental_service.remove_rental, rent.book.id))

        self.undo_redo_service.record(undo_redo_operation)

    def update_book(self, book_id, new_title, new_author):
        old_book = self.__repository.find(book_id)

        book = Book(book_id, new_title, new_author)
        self.__validator.validate(book)

        undo_redo_operation = CascadedOperation()
        undo_redo_operation.add_undo_function(FunctionCall(self.__repository.update, int(book_id), old_book.title, old_book.author))
        undo_redo_operation.add_redo_function(FunctionCall(self.__repository.update, int(book_id), new_title, new_author))

        self.undo_redo_service.record(undo_redo_operation)

        self.__repository.update(int(book_id), new_title, new_author)

    def search_books(self, search_term):
        searched_books = self.__repository.find(search_term)
        if type(searched_books) != list:
            return [searched_books]
        return searched_books
