from datetime import datetime, timedelta

from src.domain.book import Book
from src.domain.rental import Rental
from src.services.undo_service import CascadedOperation, FunctionCall


class BookRentalException(Exception):
    def __init__(self, message):
        self.__message = message

    def __str__(self):
        return str(self.__message)


class BookPopularityDTO:
    def __init__(self, book : Book, book_count):
        self.__book = book
        self.__book_count = book_count

    @property
    def book(self):
        return self.__book

    @property
    def id(self):
        return self.__book.id

    @property
    def title(self):
        return self.__book.title

    @property
    def author(self):
        return self.__book.author

    @property
    def count(self):
        return self.__book_count

    @property
    def __lt__(self, other):
        return self.__book_count > other.__book_count


class AuthorsPopularityDTO:
    def __init__(self, author, book_count):
        self.__author = author
        self.__book_count = book_count

    @property
    def author(self):
        return self.__author

    @property
    def count(self):
        return self.__book_count

    @property
    def __lt__(self, other):
        return self.__book_count > other.__book_count


class MostActiveClientsDTO:
    def __init__(self, client, rental_count):
        self.__client = client
        self.__rental_count = rental_count

    @property
    def client(self):
        return self.__client

    @property
    def count(self):
        return self.__rental_count

    @property
    def name(self):
        return self.__client.name

    @property
    def __lt__(self, other):
        return self.__rental_count > other.__rental_count


class RentalService:
    def __init__(self, validator, repository, book_repo, client_repo, undo_redo_service):
        self.__validator = validator
        self.__repository = repository
        self.__book_repo = book_repo
        self.__client_repo = client_repo
        self.undo_redo_service = undo_redo_service

    def create_rental(self, book_id, client_id, rented_date, returned_date):
        rental_id = len(self.__repository.get_all()) + 1
        book = self.__book_repo.find(book_id)
        client = self.__client_repo.find(client_id)
        rented_date = datetime.strptime(rented_date, "%Y-%m-%d").date()
        returned_date = rented_date + timedelta(days = 30) if returned_date is None else datetime.strptime(returned_date, "%Y-%m-%d").date()
        rental = Rental(rental_id, book, client, rented_date, returned_date)
        self.__validator.validate(rental)

        if self.is_book_available(rental.book, rented_date, returned_date) is False:
            raise BookRentalException("Book is not available for rental")

        self.__repository.add(rental)

        undo_redo_operation = CascadedOperation()
        undo_redo_operation.add_undo_function(FunctionCall(self.__repository.remove, rental_id))
        undo_redo_operation.add_redo_function(FunctionCall(self.__repository.add, rental))
        self.undo_redo_service.record(undo_redo_operation)

        return rental

    def is_book_available(self, book, rented_date, returned_date):
        rentals = self.filter_rentals_books(book)
        for rental in rentals:
            if rented_date < rental.returned_date and returned_date > rental.rented_date:
                return False

        return True

    def filter_rentals_books(self, book):
        results =  []
        for rental in self.__repository.get_all():
            if book is not None and rental.book != book:
                continue

            results.append(rental)
        return results

    def filter_rentals_clients(self, client):
        results =  []
        for rental in self.__repository.get_all():
            if client is not None and rental.client != client:
                continue

            results.append(rental)
        return results

    def return_rental(self, rental_id, returned_date):
        rental = self.__repository.find(rental_id)
        returned_date = datetime.strptime(returned_date, "%Y-%m-%d").date()
        new_rental = Rental(rental.id, rental.book, rental.client, rental.rented_date, returned_date)
        self.__validator.validate(new_rental)

        undo_redo_operation = CascadedOperation()
        undo_redo_operation.add_undo_function(FunctionCall(self.__repository.update, rental, rental.returned_date))
        undo_redo_operation.add_redo_function(FunctionCall(self.__repository.update, rental, returned_date))
        self.undo_redo_service.record(undo_redo_operation)

        self.__repository.update(rental, returned_date)

    def remove_rentals_by_book_id(self, book_id):
        book = self.__book_repo.find(book_id)
        for rental in self.filter_rentals_books(book):
            self.__repository.remove(rental.id)

    def remove_rentals_by_client_id(self, client_id):
        client = self.__client_repo.find(client_id)
        for rental in self.filter_rentals_clients(client):
            self.__repository.remove(rental.id)

    # def remove_rental(self, rental_id):
    #     self.__repository.remove(rental_id)

    def most_popular_books(self) -> [BookPopularityDTO]:
        book_count = {}
        for rental in self.__repository.get_all():
            if rental.book not in book_count:
                book_count[rental.book] = 1
            else:
                book_count[rental.book] += 1

        book_count = sorted(book_count.items(), key = lambda x: x[1], reverse = True)
        return [BookPopularityDTO(book, count) for book, count in book_count]

    def most_popular_authors(self) -> [AuthorsPopularityDTO]:
        author_count = {}
        for rental in self.__repository.get_all():
            if rental.book.author not in author_count:
                author_count[rental.book.author] = 1
            else:
                author_count[rental.book.author] += 1

        author_count = sorted(author_count.items(), key = lambda x: x[1], reverse = True)
        return [AuthorsPopularityDTO(author, count) for author, count in author_count]

    def most_active_clients(self) -> [MostActiveClientsDTO]:
        """
        Returns the most active clients sorted in descending order of the number of book rental days they have
        """
        client_count = {}
        for rental in self.__repository.get_all():
            if rental.client not in client_count:
                client_count[rental.client] = (rental.returned_date - rental.rented_date).days
            else:
                client_count[rental.client] += (rental.returned_date - rental.rented_date).days

        client_count = sorted(client_count.items(), key = lambda x: x[1], reverse = True)
        return [MostActiveClientsDTO(client, count) for client, count in client_count]

