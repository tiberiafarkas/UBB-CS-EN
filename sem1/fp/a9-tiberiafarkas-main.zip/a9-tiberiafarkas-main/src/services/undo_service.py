class FunctionCall:
    def __init__(self, function, *params):
        self.__function = function
        self.__params = params

    def call(self):
        self.__function(*self.__params)

    def __call__(self, *args, **kwargs):
        self.call()


class Operation:
    def __init__(self, undo_function: FunctionCall, redo_function: FunctionCall):
        self.__undo_function = undo_function
        self.__redo_function = redo_function

    def undo(self):
        self.__undo_function()

    def redo(self):
        self.__redo_function()


class CascadedOperation:
    def __init__(self):
        self.__undo_function = []
        self.__redo_function = []

    def add_undo_function(self, undo_function):
        self.__undo_function.append(undo_function)

    def add_redo_function(self, redo_function):
        self.__redo_function.append(redo_function)

    def undo(self):
        for function in self.__undo_function:
            function()

    def redo(self):
        for function in self.__redo_function:
            function()


class UndoRedoError(Exception):
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message


class UndoService:
    def __init__(self):
        self.__undo_stack = []
        self.__redo_stack = []

    def record(self, operation):
        #when an operation that is not undo or redo is performed, all stored redos are invalidated
        self.__undo_stack.append(operation)
        self.__redo_stack = []

    def undo(self):
        if len(self.__undo_stack) == 0:
            raise UndoRedoError("No more undos")

        current_operation = self.__undo_stack.pop()
        current_operation.undo()
        self.__redo_stack.append(current_operation)

    def redo(self):
        if len(self.__redo_stack) == 0:
            raise UndoRedoError("No more redos")

        current_operation = self.__redo_stack.pop()
        current_operation.redo()
        self.__undo_stack.append(current_operation)