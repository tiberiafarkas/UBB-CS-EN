import pickle

from src.repository.MemoryFileRepository import MemoryRepository


class RepositoryError(Exception):
    def __init__(self, message):
        self.__message = message

    @property
    def message(self):
        return self.__message

class DuplicateIDError(RepositoryError):
    pass

class IDNotFoundError(RepositoryError):
    pass

class BookBinaryRepo(MemoryRepository):
    def __init__(self, file_name):
        super().__init__()
        self.__file_name = file_name
        self.__load_file()

    def __load_file(self):
        try:
            with open(self.__file_name, "rb") as f:
                self._data = pickle.load(f)
            f.close()
        except (FileNotFoundError, EOFError):
            self._data = {}

    def __save(self):
        with open(self.__file_name, "wb") as f:
            pickle.dump(self._data, f)
        f.close()

    def add(self, element):
        super().add(element)
        self.__save()

    def remove(self, book_id: int):
        book_to_remove = None
        for book in self._data.values():
            if book.id == int(book_id):
                book_to_remove = book
                self.__save()
                break
        if book_to_remove:
            del self._data[book_to_remove.id]
            self.__save()
        else:
            raise KeyError(f"Book with id '{book_id}' not found")

    def update(self, book_id, new_title, new_author):
        if book_id not in self._data:
            raise IDNotFoundError("ID not found")
        self._data[book_id].title = new_title
        self._data[book_id].author = new_author
        self.__save()

    def find(self, search_term):
        results = []
        try:
            search_term = int(search_term)
            # Search by ID
            for book in self:
                if book.id == search_term:
                    results.append(book)
                    return book
        except ValueError:
            # Search by title or author
            search_term = search_term.lower()
            for book in self:
                if search_term in book.title.lower() or search_term in book.author.lower():
                    results.append(book)
        return results

    def search(self, query):
        results = [book for book in self._data.values() if query.lower() in book.title.lower() or query.lower() in book.author.lower()]
        return results

    def __iter__(self):
        return super().__iter__()

    def __len__(self):
        return super().__len__()

    def __getitem__(self, item):
        return super().__getitem__(item)

class ClientBinaryRepo(MemoryRepository):
    def __init__(self, file_name: str):
        super().__init__()
        self.__file_name = file_name
        self.__load_file()

    def __load_file(self):
        try:
            with open(self.__file_name, "rb") as f:
                self._data = pickle.load(f)
            f.close()
        except (FileNotFoundError, EOFError):
            self._data = {}

    def __save(self):
        with open(self.__file_name, "wb") as f:
            pickle.dump(self._data, f)
        f.close()

    def add(self, element):
        super().add(element)
        self.__save()

    def remove(self, client_id):
        super().remove(client_id)
        self.__save()

    def update(self, client_id, new_name):
        client_id = int(client_id)
        if client_id not in self._data:
            raise IDNotFoundError("ID not found")
        self._data[client_id].name = new_name
        self.__save()

    def find(self, search_term):
        results = []
        try:
            search_term = int(search_term)
            # Search by ID
            for client in self:
                if client.id == search_term:
                    return client
        except ValueError:
            # Search by name
            search_term = search_term.lower()
            for client in self:
                if search_term in client.name.strip().lower():
                    results.append(client)
        return results

    def search(self, query):
        results = [client for client in self._data.values() if query.lower() in client.name.lower()]
        return results

    def __iter__(self):
        return super().__iter__()

    def __len__(self):
        return super().__len__()

    def __getitem__(self, item):
        return super().__getitem__(item)

class RentalBinaryRepo(MemoryRepository):
    def __init__(self, book_repo: MemoryRepository, client_repo: MemoryRepository, file_name: str):
        super().__init__()
        self.__file_name = file_name
        self.__book_repo = book_repo
        self.__client_repo = client_repo
        self.__load_file()

    def __load_file(self):
        try:
            with open(self.__file_name, "rb") as f:
                self._data = pickle.load(f)
            f.close()
        except (FileNotFoundError, EOFError):
            self._data = {}

    def __save(self):
        with open(self.__file_name, "wb") as f:
            pickle.dump(self._data, f)
        f.close()

    def add(self, element):
        super().add(element)
        self.__save()

    def remove(self, rental_id: int):
        if rental_id not in self._data:
            raise IDNotFoundError("ID not found")
        self._data.pop(rental_id)
        self.__save()

    def update(self, rental_id, new_returned_date):
        if rental_id not in self._data:
            raise IDNotFoundError("ID not found")
        self._data[rental_id].returned_date = new_returned_date
        self.__save()

    def find(self, elem_id):
        try:
            elem_id = int(elem_id)
            for rental in self:
                if int(rental.id) == elem_id:
                    return rental
        except ValueError:
            raise ValueError(f"Rental with id {elem_id} doesn't exist")

    # def search(self, query):
    #     results = [rental for rental in self._data.values() if query.lower() in rental.client.name.lower() or query.lower() in rental.car.license.lower()]
    #     return results

    def get_all(self):
        return self._data.values()

    def __iter__(self):
        return super().__iter__()

    def __len__(self):
        return super().__len__()

    def __getitem__(self, item):
        return super().__getitem__(item)
