class RepositoryError(Exception):
    def __init__(self, message):
        self.__message = message

    @property
    def message(self):
        return self.__message

class DuplicateIDError(RepositoryError):
    pass

class IDNotFoundError(RepositoryError):
    pass

class RepositoryIterator:
    def __init__(self, data):
        self.__data = data
        self.__pos = -1

    def __next__(self):
        self.__pos += 1
        if len(self.__data) == self.__pos:
            # we have run out of elements in the data structure
            raise StopIteration()

        return self.__data[self.__pos]

class MemoryRepository:
    def __init__(self):
        self._data = {}

    def add(self, element):
        if element.id in self._data:
            raise DuplicateIDError("Duplicate object ID")
        self._data[element.id] = element

    def remove(self, elem):
        element_to_remove = None
        for element in self._data.values():
            if element.id == int(elem):
                element_to_remove = element
                break
        if element_to_remove:
            del self._data[element_to_remove.id]
        else:
            raise KeyError(f"{elem} not found")

    def find(self, elem_id: int):
        if elem_id not in self._data:
            return None
        return self._data[elem_id]

    def __iter__(self):
        return iter(self._data.values())

    def __len__(self):
        return len(self._data)

    def __getitem__(self, item):
        if item not in self._data:
            return None
        return self._data[item]
