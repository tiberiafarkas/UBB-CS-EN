#include "Sem6.h"

Sem6::Sem6(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
}

Sem6::~Sem6()
{}
