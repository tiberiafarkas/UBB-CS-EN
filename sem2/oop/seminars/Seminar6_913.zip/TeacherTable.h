#pragma once

#include <QWidget>
#include "ui_TeacherTable.h"

class TeacherTable : public QWidget
{
	Q_OBJECT

public:
	TeacherTable(QAbstractItemModel *tableModel, bool isMainTeacher, QWidget *parent = nullptr);
	~TeacherTable();

private:
	Ui::TeacherTableClass ui;
	bool isMainTeacher;
	QAbstractItemModel *tableModel;
};
