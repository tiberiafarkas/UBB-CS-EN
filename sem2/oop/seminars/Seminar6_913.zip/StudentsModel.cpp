#include "StudentsModel.h"

int StudentsModel::rowCount(const QModelIndex &parent) const
{
	return this->repo.getSize();
}

int StudentsModel::columnCount(const QModelIndex &parent) const
{
	return 4;
}

QVariant StudentsModel::data(const QModelIndex &index, int role) const
{
	if (role == Qt::DisplayRole || role == Qt::EditRole)
	{
		int row = index.row();
		switch (index.column())
		{
		case 0:
			return QVariant{ QString::fromStdString(this->repo.getStudents()[row].getName()) };
			break;
		case 1:
			return QVariant{ QString::fromStdString(this->repo.getStudents()[row].getGroup()) };
			break;
		case 2:
			return QVariant{ QString::number(this->repo.getStudents()[row].getLabGrade()) };
			break;
		case 3:
			return QVariant{ QString::number(this->repo.getStudents()[row].getSeminarGrade()) };
			break;
		default:
			break;
		}
	}
	return QVariant{};
}

bool StudentsModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
	if (role != Qt::EditRole)
		return false;

	int row = index.row();
	int col = index.column();

	Student &currentStudent = this->repo.getStudents()[row];

	switch (col)
	{
	case 0:
		// edit name
		break;
	case 1:
		// edit group
		break;
	case 2:
		currentStudent.setLabGrade(std::stod(value.toString().toStdString()));
		break;
	case 3:
		currentStudent.setSeminarGrade(std::stod(value.toString().toStdString()));
		break;
	default:
		break;
	}

	emit dataChanged(index, index);
	return true;
}

QVariant StudentsModel::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (role == Qt::DisplayRole || role == Qt::EditRole)
	{
		if (orientation == Qt::Horizontal)
		{
			switch (section)
			{
			case 0:
				return QVariant{ "Name" };
			case 1:
				return QVariant{ "Group" };
			case 2:
				return QVariant{ "Lab Grade" };
			case 3:
				return QVariant{ "Seminar Grade" };
			default:
				break;
			}
		}
	}
	return QVariant{};
}

Qt::ItemFlags StudentsModel::flags(const QModelIndex &index) const
{
	if (index.column() == 0 || index.column() == 1)
		return Qt::ItemFlags{};
	return Qt::ItemFlags{ Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable };
}