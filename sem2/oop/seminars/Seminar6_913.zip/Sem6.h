#pragma once

#include <QtWidgets/QWidget>
#include "ui_Sem6.h"

class Sem6 : public QWidget
{
    Q_OBJECT

public:
    Sem6(QWidget *parent = nullptr);
    ~Sem6();

private:
    Ui::Sem6Class ui;
};
