#include "Sem6.h"
#include <QtWidgets/QApplication>
#include <QSortFilterProxyModel>
#include <QRegularExpression>
#include "StudentsModel.h"
#include "TeacherTable.h"
#include "Repository.h"

// Will not work because it will destroy the window when getting out of scope:
// 
//void createTeacherWindow(StudentsModel *studentModel, std::string group)
//{
//    QSortFilterProxyModel *regularTeacher = new QSortFilterProxyModel{};
//    regularTeacher->setSourceModel(studentModel);
//
//    QString groupFilter{ QString::fromStdString(group) };
//    regularTeacher->setFilterRegularExpression(QRegularExpression{ groupFilter });
//    regularTeacher->setFilterKeyColumn(1);
//
//    TeacherTable regularTeacherTable{ regularTeacher, false };
//    regularTeacherTable.setWindowTitle("Regular Teacher - " + groupFilter);
//    regularTeacherTable.show();
//}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    /*Sem6 w;
    w.show();*/

    Repository r{ "Students.txt" };
    StudentsModel *studentModel = new StudentsModel{r};

    QSortFilterProxyModel *mainTeacher = new QSortFilterProxyModel{};
    mainTeacher->setSourceModel(studentModel);
    TeacherTable mainTeacherTable{ mainTeacher, true };
    mainTeacherTable.setWindowTitle("Main Teacher");
    mainTeacherTable.show();

    // Will not work because it will destroy the window when getting out of scope:
    // 
    //createTeacherWindow(studentModel, "911");

    std::string group = "912";
    QSortFilterProxyModel *regularTeacher = new QSortFilterProxyModel{};
    regularTeacher->setSourceModel(studentModel);

    QString groupFilter{ QString::fromStdString(group) };
    regularTeacher->setFilterRegularExpression(QRegularExpression{ groupFilter });
    regularTeacher->setFilterKeyColumn(1);

    TeacherTable regularTeacherTable{ regularTeacher, false };
    regularTeacherTable.setWindowTitle("Regular Teacher - " + groupFilter);
    regularTeacherTable.show();
    return a.exec();
}
