#include "TeacherTable.h"

TeacherTable::TeacherTable(QAbstractItemModel *tableModel, bool isMainTeacher, QWidget *parent)
	: tableModel(tableModel), isMainTeacher(isMainTeacher), QWidget(parent)
{
	ui.setupUi(this);
	
	ui.studentsTable->setModel(tableModel);
	if (this->isMainTeacher)
	{
		ui.studentsTable->setSortingEnabled(true);
	}
	else
	{
		ui.studentsTable->hideColumn(1);
	}
}

TeacherTable::~TeacherTable()
{}
