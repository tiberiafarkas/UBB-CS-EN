#include "Planet.h"
#include <crtdbg.h>
#include <stdio.h>
#include "DynamicArray.h"

int main() {

	Planet* p = createPlanet("Mars", "Terrestrial", 2);
	Planet* q = createPlanet("a", "b", 1);
	printf("Planet's name: %s", getName(p));
	//destroyPlanet(p);

	DynamicArray* arr = createDynamicArray(1);
	append(arr, p);
	append(arr, q);
	printf("\n%d\n", getSize(arr));
	/*destroyPlanet(p);
	destroyPlanet(q);*/
	destroyArray(arr);
	
	_CrtDumpMemoryLeaks();

	return 0;
}