#include <stdlib.h>
#include "Repository.h"
Repository* createRepository()
{
	Repository* repo = malloc(sizeof(Repository));
	if (repo == NULL)
		return NULL;
	repo->da = createDynamicArray(1);
	return repo;
}

void destroyRepository(Repository* repo)
{
	if (repo == NULL)
		return;
	destroyArray(repo->da);
	free(repo);
}

void addElement(Repository* repo, TElem* elem)
{
	if (repo->da == NULL)
		return;
	append(repo->da, elem);
}