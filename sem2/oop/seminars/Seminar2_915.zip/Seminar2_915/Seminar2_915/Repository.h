#pragma once
#include "DynamicArray.h"
typedef struct {
	DynamicArray* da;

}Repository;

Repository* createRepository();
void destroyRepository(Repository* repo);
void addElement(Repository* repo, TElem* elem);