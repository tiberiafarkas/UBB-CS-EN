#pragma once
#include "Planet.h"

typedef void* TElem;

typedef struct {
	TElem* elems;
	int size, capacity;
} DynamicArray;


DynamicArray* createDynamicArray(int capacity);
void append(DynamicArray* arr, TElem p);
void destroyArray(DynamicArray* arr);
int getSize(DynamicArray* arr);