#include "Planet.h"
#include <stdlib.h>
#include <string.h>

Planet* createPlanet(char* name, char* type, int dist)
{
	Planet* p = malloc(sizeof(Planet));
	if (p == NULL)
		return NULL;

	p->name = malloc(sizeof(char) * (strlen(name) + 1));
	if (p->name == NULL)
		return NULL;
	strcpy(p->name, name);

	p->type = malloc(sizeof(char) * (strlen(type) + 1));
	if (p->type == NULL)
		return NULL;
	strcpy(p->type, type);

	p->distance = dist;

	return p;
}

void destroyPlanet(Planet* p)
{
	if (p == NULL)
		return;

	free(p->name);
	free(p->type);
	free(p);

	// !!! To make p NULL you would need to pass a pointer to the pointer
	// Planet**
	// p = NULL;
}

char* getName(Planet* p)
{
	return p->name;
}
