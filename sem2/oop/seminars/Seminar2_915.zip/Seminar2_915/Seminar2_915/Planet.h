#pragma once

typedef struct {
	char* name;
	char* type;
	int distance;
} Planet;

Planet* createPlanet(char* name, char* type, int dist);
void destroyPlanet(Planet* p);
char* getName(Planet* p);

