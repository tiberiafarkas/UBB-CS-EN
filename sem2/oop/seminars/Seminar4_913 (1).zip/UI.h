#pragma once
#include "Service.h"

class UI {
private:
	void printMenu();
	void printAll();
	void addSong();
	void addToPlaylist();
	Service& service;
public:
	UI(Service &service) : service(service) {}
	void start();
};