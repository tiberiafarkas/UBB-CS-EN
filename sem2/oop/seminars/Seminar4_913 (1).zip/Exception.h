#pragma once
#include <exception>
#include <string>

class RepositoryException : public std::exception {
private:
	std::string message;
public:
	RepositoryException(std::string msg) : message("REPOSITORY:" + msg) {}
	const char* what() { return message.c_str(); };
};
