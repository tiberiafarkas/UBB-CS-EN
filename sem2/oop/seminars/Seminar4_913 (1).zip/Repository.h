#pragma once
#include "DynamicArray.h"
#include "Song.h"

class Repository {
public:
	virtual void add(const Song &s) = 0;
	virtual std::vector<Song> getElements() = 0;
	virtual ~Repository() {}
};

class MemoryRepository : public Repository {
private:
	std::vector<Song> elements;
public:
	void add(const Song &s) override;
	std::vector<Song> getElements() override;
};