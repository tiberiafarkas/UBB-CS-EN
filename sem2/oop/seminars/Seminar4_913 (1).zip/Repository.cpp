#include "Repository.h"

void MemoryRepository::add(const Song &s) {
	this->elements.push_back(s);
}

std::vector<Song> MemoryRepository::getElements(){
	return this->elements;
}

