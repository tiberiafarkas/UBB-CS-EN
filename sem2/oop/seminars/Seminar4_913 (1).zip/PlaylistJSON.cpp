#include "PlaylistJSON.h"

#include <fstream>

PlaylistJSON::PlaylistJSON(string filePath) : filePath(filePath){}

void PlaylistJSON::add(const Song &s) {
	this->elements.push_back(s);
	this->writeToFile();
}

std::vector<Song> PlaylistJSON::getElements() {
	return this->elements;
}

void PlaylistJSON::writeToFile() {
	ofstream fout(this->filePath);
	if (fout.is_open() == false)
		throw exception("File not open!");
	fout << "[\n";
	for (int i = 0; i < this->elements.size(); i++)
	{
		/*fout << "<song>";
		fout << "<songTitle>" << this->elements[i].getTitle() << "</songTitle>";
		fout << "<songArtist>" << this->elements[i].getArtist() << "</songArtist>";
		fout << "<songDuration>";
		fout << "<minutes>" << this->elements[i].getDuration().minutes << "</minutes>";
		fout << "<seconds>" << this->elements[i].getDuration().seconds << "</seconds>";
		fout << "</songDuration>";
		fout << "</song>";*/

		fout << "{\n";
		fout << "\"title\" :\"" << this->elements[i].getTitle() << "\",\n";
		fout << "\"artist\": \"" << this->elements[i].getArtist() << "\",\n";
		fout << "\"duration\": {";
		fout << "\"minutes\": " << this->elements[i].getDuration().minutes << ", ";
		fout << "\"seconds\": " << this->elements[i].getDuration().seconds << " ";
		fout << "} \n";
		fout << "}";
		if (i < this->elements.size() - 1)
			fout << ",\n";
	}
	fout << "]";
	fout.close();
}