#include "UI.h"
#include <iostream>

using namespace std;

void UI::start()
{
	while (true)
	{
		printMenu();
		int command;
		cin >> command;
		cin.ignore();
		switch (command) {
		case 0:
			return;
		case 1:
			printAll();
			break;
		case 2:
			addSong();
		case 3:
			addToPlaylist();
			break;
		}
	}
}

void UI::printMenu() 
{
	cout << "0 - Exit\n";
	cout << "1 - Print All\n";
	cout << "2 - Add Song\n";
	cout << "3 - Add All To Playlist\n";
	cout << "Enter command: ";
}

void UI::printAll() 
{
	vector<Song> mySongs2 = this->service.getElements();
	for (int i = 0; i < mySongs2.size(); i++) {
		cout << mySongs2[i] << '\n';
	}
}

void UI::addSong()
{
	cout << "Enter song (artist,title,minutes:seconds) ";
	Song song;
	cin >> song;
	service.add(song);
}

void UI::addToPlaylist()
{
	for (int i = 0; i < this->service.getElements().size(); ++i) {
		this->service.addToPlaylist(this->service.getElements()[i]);
	}
}