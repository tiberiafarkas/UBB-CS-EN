#pragma once
#include <string>

using namespace std;

struct Duration {
public:
	int minutes;
	int seconds;
	Duration(int minutes = 0, int seconds = 0) : minutes{ minutes }, seconds{ seconds } {};
};

class Song {
private:
	string artist;
	string title;
	Duration duration;
public:
	Song(string artist, string title, const Duration &duration);
	Song();
	string getTitle();
	string getArtist();
	Duration getDuration();
	friend istream& operator >> (istream &is, Song &song);
	friend ostream& operator << (ostream &os, const Song &song);
};