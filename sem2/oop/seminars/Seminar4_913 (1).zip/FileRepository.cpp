#include "FileRepository.h"
#include "Exception.h"
#include <fstream>

FileRepository::FileRepository(string filePath) : filePath(filePath)
{
	readFromFile();
}

void FileRepository::add(const Song &s) {
	this->elements.push_back(s);
	this->writeToFile();
}

std::vector<Song> FileRepository::getElements() {
	return this->elements;
}

void FileRepository::readFromFile() {
	ifstream fin(this->filePath);
	if (fin.is_open() == false)
		throw RepositoryException("File not open!");
	Song s;
	while (fin >> s)
	{
		this->elements.push_back(s);
	}
	fin.close();
}

void FileRepository::writeToFile() {
	ofstream fout(this->filePath);
	if (fout.is_open() == false)
		throw exception("File not open!");
	for (int i = 0; i < this->elements.size(); i++)
	{
		fout << this->elements[i] << '\n';
	}
}