#pragma once
#include "Repository.h"
#include "Playlist.h"

class Service {
private:
	Repository& repository;
	Playlist&playlist;
public:
	Service(Repository& repository, Playlist& playlist) : repository(repository), playlist(playlist) {}
	std::vector<Song> getElements();
	void add(const Song& song);
	void addToPlaylist(const Song& song);
};
