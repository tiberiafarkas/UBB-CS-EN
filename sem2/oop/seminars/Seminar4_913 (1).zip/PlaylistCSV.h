#pragma once
#include "Playlist.h"
#include <vector>
#include <string>

class PlaylistCSV : public Playlist {
private:
	std::vector<Song> elements;
	string filePath;
public:
	PlaylistCSV(string filePath);
	void add(const Song &s) override;
	std::vector<Song> getElements() override;
private:
	void writeToFile();
	void readFromFile();
};