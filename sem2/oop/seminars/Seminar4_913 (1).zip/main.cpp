#include <iostream>
#include "UI.h"
#include "FileRepository.h"
#include "Playlist.h"
#include "PlaylistJSON.h"
#include "PlaylistCSV.h"
#include "Exception.h"

void InitMemoryRepo(Repository& repo) {
    Song s{ "a1", "t1", { 1, 1 } };
    repo.add(s);
}

Repository *getRepo() {
    Repository *repo = nullptr;
    cout << "Enter repository type (1-memory, 2-file): ";
    int option;
    cin >> option;
    switch (option)
    {
    case (1):
        repo = new MemoryRepository();
        InitMemoryRepo(*repo);
        break;
    case (2):
        try {
            repo = new FileRepository(""); //fix: "songs.txt"
        }
        catch (RepositoryException e) {
            cout << e.what() << '\n';
            return nullptr;
        }
        break;
    default:
        cout << "Not a suitable option!";
        return 0;
    }
    return repo;
}

Playlist* getPlaylist() {
    Playlist *playlist = nullptr;
    cout << "Enter playlist type (1-CSV, 2-JSON): ";
    int option;
    cin >> option;
    switch (option)
    {
    case (1):
        playlist = new PlaylistCSV("playlist.csv");
        break;
    case (2):
        playlist = new PlaylistJSON("playlist.json");
        break;
    default:
        cout << "Not a suitable option!";
        return 0;
    }
    return playlist;
}

int main()
{
    Service service{ *getRepo(), *getPlaylist() }; //TODO: if exceptions/nullptr, print message and return

    UI ui{service};
    ui.start();

    return 0;
}