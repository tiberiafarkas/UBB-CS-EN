#pragma once
#include "Repository.h"

class FileRepository : public Repository {
private:
	std::vector<Song> elements;
	string filePath;
public:
	FileRepository(string filePath);
	void add(const Song &s) override;
	std::vector<Song> getElements() override;
private:
	void writeToFile();
	void readFromFile();
};