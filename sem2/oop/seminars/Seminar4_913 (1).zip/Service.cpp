#include "Service.h"

std::vector<Song> Service::getElements() 
{
	return this->repository.getElements();
}

void Service::add(const Song &song) 
{
	this->repository.add(song);
}

void Service::addToPlaylist(const Song &song)
{
	this->playlist.add(song);
}