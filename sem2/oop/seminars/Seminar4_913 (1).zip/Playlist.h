#pragma once
#include "Song.h"
#include <vector>

class Playlist {
public:
	virtual void add(const Song &s) = 0;
	virtual std::vector<Song> getElements() = 0;
	virtual ~Playlist() {}
};