#include "PlaylistCSV.h"
#include <fstream>

PlaylistCSV::PlaylistCSV(string filePath) : filePath(filePath) {}

void PlaylistCSV::add(const Song &s) {
	this->elements.push_back(s);
	this->writeToFile();
}

std::vector<Song> PlaylistCSV::getElements() {
	return this->elements;
}

void PlaylistCSV::writeToFile() {
	ofstream fout(this->filePath);
	if (fout.is_open() == false)
		throw exception("File not open!");
	for (int i = 0; i < this->elements.size(); i++)
	{
		fout << this->elements[i] << "\n";
	}
	fout.close();
}