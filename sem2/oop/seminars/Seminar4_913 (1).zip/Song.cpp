#define _CRT_SECURE_NO_WARNINGS
#include "Song.h"
#include "Utils.h"
#include <iostream>

Song::Song(string artist, string title, const Duration &duration) : duration(duration) {
	this->artist = artist;
	this->title = title;
}

Song::Song()
{
	this->artist[0] = '\0';
	this->title[0] = '\0';
}

string Song::getTitle() { return title; }
string Song::getArtist() { return artist; }
Duration Song::getDuration() { return duration; }

ostream &operator << (ostream &os, const Song &song) 
{
	os << song.artist << ',' << song.title << ',' << song.duration.minutes << ':' << song.duration.seconds;
	return os;
}	

istream& operator >> (istream &is, Song &song) 
{
	string songString;
	getline(is, songString);
	vector<string> result = tokenize(songString, ',');
	if (result.size() != 3)
		return is;

	vector<string> durationResult = tokenize(result[2], ':');
	if (durationResult.size() != 2)
		return is;

	Duration d{ stoi(durationResult[0]), atoi(durationResult[1].c_str()) };
	Song s{ result[0], result[1], d};
	song = s;
	return is;
}